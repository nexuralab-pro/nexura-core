#!/bin/bash
# ---------------------------------------------------------------------
# NEXURA LAB - SCRIPT AUTOMATIZADO DE RESPALDOS COMPACTOS (LOGS Y DATA)
# ---------------------------------------------------------------------

RESPALDO_DIR="/var/backups/nexura_critical"
FECHA=$(date +%Y-%m-%d_%H-%m-%s)
ORIGEN="/var/www/html/storage/app/public"

echo "[NEXURA LAB] Inicializando respaldo de seguridad en $FECHA..."

# Crear directorio de destino si no existe
if [ ! -d "$RESPALDO_DIR" ]; then
    mkdir -p "$RESPALDO_DIR"
fi

# Compactar y empaquetar la información
tar -czf "$RESPALDO_DIR/backup_data_$FECHA.tar.gz" "$ORIGEN" 2>/dev/null

# Retención: Eliminar respaldos más viejos de 7 días para proteger el almacenamiento
find "$RESPALDO_DIR" -type f -name "*.tar.gz" -mtime +7 -exec rm {} \;

echo "[NEXURA LAB] Proceso finalizado con éxito. Copia de seguridad guardada."